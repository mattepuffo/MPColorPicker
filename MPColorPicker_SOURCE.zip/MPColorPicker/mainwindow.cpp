#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent), ui(new Ui::MainWindow) {
    ui->setupUi(this);

    QColorDialog *colorDialog = new QColorDialog(this);
    colorDialog->setOptions(QColorDialog::DontUseNativeDialog | QColorDialog::NoButtons);

    setCentralWidget(new QWidget);
    centralWidget()->setLayout(new QVBoxLayout());
    centralWidget()->layout()->setAlignment(Qt::AlignCenter);
    centralWidget()->layout()->addWidget(colorDialog);
    connect(ui->actionAbout, SIGNAL(triggered()), this, SLOT(onActionAbout()));
}

void MainWindow::onActionAbout() {
    MessageDialog *ms = new MessageDialog("About",
                                          qApp->applicationName() +
                                          "<br><br>"
                                          "Web site: https://www.mattepuffo.com"
                                          "<br><br>"
                                          "Licenza: https://www.mattepuffo.com/blog/copyright.html"
                                          "<br><br>"
                                          "Linguaggio: C++/Qt<br><br>"
                                          "Versione: " + qApp->applicationVersion() +
                                          "<br><br>"
                                          "Versione Qt: " + QT_VERSION_STR
                                          );
    ms->show();
}

MainWindow::~MainWindow() {
    delete ui;
}
